package insuranceProduct;


/**
 * @author dongyeonkim
 * @version 1.0
 * @created 14-5-2024 ���� 6:43:15
 */
public class ProductApprovalPaper {

	public String forDemo;

	public ProductApprovalPaper(String str){
		this.forDemo = str;
	}

	public void finalize() throws Throwable {

	}

}
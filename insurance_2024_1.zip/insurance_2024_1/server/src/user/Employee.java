package user;


/**
 * @author dongyeonkim
 * @version 1.0
 * @created 14-5-2024 ���� 6:43:14
 */
public class Employee extends User {

	public Employee(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}
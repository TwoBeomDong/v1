package contractInsurance;

import java.util.Vector;

/**
 * @author dongyeonkim
 * @version 1.0
 * @created 14-5-2024 ���� 6:43:14
 */
public class ContractInsuranceList {

	private Vector<ContractInsurance> contractInsuranceList;

	public ContractInsuranceList(){

	}

	public void finalize() throws Throwable {

	}

	public void AddContractInsurance(){

	}

}